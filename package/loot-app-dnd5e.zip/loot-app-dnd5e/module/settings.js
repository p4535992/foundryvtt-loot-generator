export const MODULE_NAME = 'loot-app-dnd5e';
export const registerSettings = function () {
};
