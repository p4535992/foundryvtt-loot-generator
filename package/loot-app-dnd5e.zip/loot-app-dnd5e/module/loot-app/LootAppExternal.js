function toCoins(denomination, value) {
    return {
        pp: denomination === 'pp' ? value : 0,
        gp: denomination === 'gp' ? value : 0,
        sp: denomination === 'sp' ? value : 0,
        cp: denomination === 'cp' ? value : 0,
    };
}
function noCoins() {
    return {
        pp: 0,
        gp: 0,
        sp: 0,
        cp: 0,
    };
}
function combineCoins(first, second) {
    return {
        pp: first.pp + second.pp,
        gp: first.gp + second.gp,
        sp: first.sp + second.sp,
        cp: first.cp + second.cp,
    };
}
export function calculateWealth(items) {
    return items
        .filter((item) => { var _a, _b, _c, _d; return item.type === 'treasure' && ((_b = (_a = item === null || item === void 0 ? void 0 : item.data) === null || _a === void 0 ? void 0 : _a.denomination) === null || _b === void 0 ? void 0 : _b.value) !== undefined && ((_d = (_c = item === null || item === void 0 ? void 0 : item.data) === null || _c === void 0 ? void 0 : _c.denomination) === null || _d === void 0 ? void 0 : _d.value) !== null; })
        .map((item) => {
        var _a, _b, _c, _d, _e, _f;
        const value = ((_c = (_b = (_a = item.data) === null || _a === void 0 ? void 0 : _a.value) === null || _b === void 0 ? void 0 : _b.value) !== null && _c !== void 0 ? _c : 1) * ((_f = (_e = (_d = item.data) === null || _d === void 0 ? void 0 : _d.quantity) === null || _e === void 0 ? void 0 : _e.value) !== null && _f !== void 0 ? _f : 1);
        return toCoins(item.data.denomination.value, value);
    })
        .reduce(combineCoins, noCoins());
}
